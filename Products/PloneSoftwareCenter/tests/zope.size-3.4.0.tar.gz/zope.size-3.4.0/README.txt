zope.size Package Readme
========================

Overview
--------

Interfaces and adapters that give the size of an object.
